let button = null;

function createButton() {
    if (!button) {
        button = document.createElement('button');
        button.innerHTML = 'Find High Quality Video';
        button.style.cssText = 'position: fixed; top: 10px; right: 10px; z-index: 9999; padding: 10px; background: #4CAF50; color: white; border: none; cursor: pointer; border-radius: 5px;';

        button.addEventListener('click', function() {
            const pageSource = document.documentElement.outerHTML;
            const regex = /html5player\.setVideoUrlHigh\('(https:\/\/[^']+\.mp4[^']*)'/i;
            const match = pageSource.match(regex);
            
            if (match && match[1]) {
                window.open(match[1], '_blank');
            } else {
                alert('No high quality video source found!');
            }
        });
    }
    document.body.appendChild(button);
}

function removeButton() {
    if (button && button.parentNode) {
        button.parentNode.removeChild(button);
    }
}

// Listen for messages from the background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "toggleButton") {
        if (button && button.parentNode) {
            removeButton();
        } else {
            createButton();
        }
    }
}); 